﻿using System;
using System.Reflection;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace massiv
{
    class Program
    {
        static void Main(string[] args)
        {
            //Задание 1
            //int[] myarray = new int[5];
            //for (int i = 0; i < myarray.Length; i++)
            //{
            //    Console.Write($"myarray[{i}]=");
            //    myarray[i] = int.Parse(Console.ReadLine());
            //}
            //int max = myarray[0];
            //int index = 0;
            //for (int i = 0; i < myarray.Length; i++)
            //{
            //    if (myarray[i] > max)
            //    {
            //        max = myarray[i];
            //        index = i;

            //    }
            //}
            //Console.WriteLine($"max = {max}/tindex = {index}");
            //Console.ReadLine();

            //Задание 2
            //int[] myarray = new int[5];
            //for (int i = 0; i < myarray.Length; i++)
            //{
            //    Console.Write($"myarray[{i}]=");
            //    myarray[i] = int.Parse(Console.ReadLine());
            //}
            //int max = myarray[0]; int indexmax = 0;
            //int min = myarray[0]; int indexmin = 0;

            //for (int i = 0; i < myarray.Length; i++)
            //{
            //    if (myarray[i] > max)
            //    {
            //        max = myarray[i];
            //        indexmax = i;

            //    }
            //}
            //for (int i = 0; i > myarray.Length; i++)
            //{
            //    if (myarray[i] < min)
            //    {
            //        min = myarray[i];
            //        indexmin = i;

            //    }
            //}
            //Console.WriteLine($"max = {max} index max = {indexmax}\nmin = {min} index min = {indexmin}");
            //Console.ReadLine();

            //Задание 3
            //int[] array3 = new int[10];
            //int count = 0;

            //for (int i = 0; i < array3.Length; i++)
            //{
            //    Console.Write($"Введите значение {i} элемента массива: ");
            //    array3[i] = int.Parse(Console.ReadLine());
            //}

            //int IndexMin, IndexMax;
            //IndexMin = Array.IndexOf(array3, array3.Min());
            //IndexMax = Array.IndexOf(array3, array3.Max());

            //if (IndexMin > IndexMax)
            //{
            //    IndexMin = Array.IndexOf(array3, array3.Max());
            //    IndexMax = Array.IndexOf(array3, array3.Min());
            //}

            //for (var b = IndexMin; b <= IndexMax; b++)
            //{
            //    count++;
            //}

            //Console.WriteLine($"Count: {count}");

            //Задание 4
            int [] array1 = new int[10]; 
            for (int i = 0; i < array1.Length; i++)
            {
                Console.Write($"Введите значение {i} элемента массива: ");
                array1[i] = int.Parse(Console.ReadLine());
            }
            for (int i = 0; i < array1.Length; i++)
            {
               int b = array1[i] += array1.Max() + array1.Min();
            }
            Console.WriteLine);
        }
    }
}
